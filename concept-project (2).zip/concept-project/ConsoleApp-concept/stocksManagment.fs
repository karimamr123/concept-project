﻿module StocksManagement

open first


// Product Management

let addProduct name price quantity =
    "INSERT INTO Products (Name, Price, Quantity) VALUES (@name, @price, @quantity);",
    [ "@name", box name; "@price", box price; "@quantity", box quantity ]

let updateProduct productId name price quantity =
    let queryCheck = "SELECT Deleted FROM Products WHERE ProductID = @id;"
    let parametersCheck = [ "@id", box productId ]
    
    let result = executeReadQuery queryCheck parametersCheck

    match result with
    | [[deletedObj]] -> 
        let deleted = System.Convert.ToBoolean(deletedObj)
        if deleted then
            None // when product cannot be updated
        else
            Some ("UPDATE Products SET Name = @name, Price = @price, Quantity = @quantity WHERE ProductID = @id;",
                   [ "@id", box productId; "@name", box name; "@price", box price; "@quantity", box quantity ])
    | _ -> None // Product not found

let deleteProduct productId =
    "UPDATE Products SET Deleted = TRUE WHERE ProductID = @id;",
    [ "@id", box productId ]

// Inventory Tracking

let checkLowStock threshold =
    "SELECT * FROM Products WHERE Quantity < @threshold;",
    [ "@threshold", box threshold ]

let updateStockRecursively productsUpdates =
    let rec update products =
        match products with
        | [] -> []
        | (productId, quantity) :: tail ->
            let queryCheck = "SELECT Deleted FROM Products WHERE ProductID = @id;"
            let parametersCheck = [ "@id", box productId ]
            
            let result = executeReadQuery queryCheck parametersCheck

            match result with
            | [[deletedObj]] -> 
                let deleted = System.Convert.ToBoolean(deletedObj)
                if deleted then
                    update tail
                else
                    let queryUpdate =
                        "UPDATE Products SET Quantity = Quantity + @quantity WHERE ProductID = @id AND Deleted = FALSE;"
                    let parametersUpdate = [ "@id", box productId; "@quantity", box quantity ]
                    (queryUpdate, parametersUpdate) :: update tail
            | _ -> update tail // Product not found

    update productsUpdates

// Order Management

let processOrder productId orderQuantity =
    let checkProductDeletedQuery = "SELECT Deleted FROM Products WHERE ProductID = @id;"
    let productStatus = executeReadQuery checkProductDeletedQuery [ "@id", box productId ]
    
    match productStatus with
    | [ [ deletedStatus ] ] ->
        let deleted = System.Convert.ToBoolean(deletedStatus)
        
        if deleted then
            Error("Cannot place an order for a deleted product.")
        else
            let queryProduct = "SELECT Price, Quantity FROM Products WHERE ProductID = @id;"
            let product = executeReadQuery queryProduct [ "@id", box productId ]
            
            match product with
            | [ [ priceObj; stockObj ] ] ->
                let price = System.Convert.ToDecimal(priceObj)
                let stock = System.Convert.ToInt32(stockObj)

                if stock >= orderQuantity then
                    let totalPrice = price * decimal orderQuantity

                    let actions = [
                        ("UPDATE Products SET Quantity = Quantity - @quantity WHERE ProductID = @id;",
                         [ "@id", box productId; "@quantity", box orderQuantity ])
                         
                        ("INSERT INTO Orders (ProductID, Quantity, TotalPrice) VALUES (@id, @quantity, @totalPrice);",
                         [ "@id", box productId; "@quantity", box orderQuantity; "@totalPrice", box totalPrice ])
                    ]

                    Ok(actions, totalPrice)
                else
                    Error(sprintf "Insufficient stock. Available: %d, Required: %d" stock orderQuantity)
            | _ ->
                Error("Product not found.")
    | _ ->
        Error("Error checking product status.")

// Report Generators

let generateLowStockReport threshold =
    let query, parameters = checkLowStock threshold
    executeReadQuery query parameters

let calculateTotalSales () =
    let query = "SELECT SUM(TotalPrice) FROM Orders;"
    match executeReadQuery query [] with
    | [ [ value ] ] -> Some value
    | _ -> None

let calculateInventoryValue () =
    let query = "SELECT SUM(Price * Quantity) FROM Products;"
    match executeReadQuery query [] with
    | [ [ value ] ] -> Some value
    | _ -> None

let executeQueries queries =
    queries |> List.map (fun (query, parameters) -> executeQuery query parameters)

// Execute

[<EntryPoint>]
let main argv =
    // Example usage of the functions
    //let addquery = addproduct "harry potter book" 29.99m 10
    //let queries = [addquery] |> list.map (fun (query, parameters) -> (query, parameters))
    //executequeries queries |> ignore

    //let updateProductQuery = updateProduct 14 "dancing cactus" 103.00m 23
    //match updateProductQuery with
    //| Some (query, parameters) -> executeQuery query parameters |> ignore
    //| None -> printfn "Product cannot be updated."

    //let productId = 9  
    //let deleteQuery = deleteProduct productId
    //let query, parameters = deleteQuery  
    //executeQuery query parameters |> ignore

    //let orderProductId = 1 
    //let orderQuantity = 3
    //let result = processOrder orderProductId orderQuantity
    //match result with
    //| Ok(actions, totalPrice) ->
    //    actions |> List.iter (fun (query, parameters) -> executeQuery query parameters |> ignore)
    //    printfn "Order processed successfully. Total Price: %A" totalPrice
    //| Error message ->
    //    printfn "Error: %s" message

    //let productsToUpdate = [ (7, 3); (11, -5) ]  
    //let queriesToUpdate = updateStockRecursively productsToUpdate
    //queriesToUpdate |> List.iter (fun (query, parameters) -> executeQuery query parameters |> ignore)

    //let lowStockProducts = generateLowStockReport 15
    //lowStockProducts |> List.iter (printfn "Low Stock Product: %A")

    //match calculateTotalSales () with
    //| Some value -> printfn "Total Sales: %A" value
    //| None -> printfn "Could not calculate total sales."

    //match calculateInventoryValue () with
    //| Some value -> printfn "Inventory Value: %A" value
    //| None -> printfn "Could not calculate inventory value."

    0 // Exit code
