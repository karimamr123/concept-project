﻿module StocksManagement

open first

    //Product Management:-

let addProduct name price quantity =
    let query = "INSERT INTO Products (Name, Price, Quantity) VALUES (@name, @price, @quantity);"
    query, [ "@name", box name; "@price", box price; "@quantity", box quantity ]

let updateProduct productId name price quantity =
    let query = "UPDATE Products SET Name = @name, Price = @price, Quantity = @quantity WHERE ProductID = @id;"
    query, [ "@id", box productId; "@name", box name; "@price", box price; "@quantity", box quantity ]


let deleteProduct productId =
    let query = "DELETE FROM Products WHERE ProductID = @id;"
    query, [ "@id", box productId ]

    //Inventory Tracking:-

let updateStock productId quantity =
    let query = "UPDATE Products SET Quantity = Quantity + @quantity WHERE ProductID = @id;"
    query, [ "@id", box productId; "@quantity", box quantity ]

let checkLowStock threshold =
    let query = "SELECT * FROM Products WHERE Quantity < @threshold;"
    query, [ "@threshold", box threshold ]



    //Order Management:- 

let processOrder productId orderQuantity =
    let queryProduct = "SELECT Price, Quantity FROM Products WHERE ProductID = @id;"
    let product = executeReadQuery queryProduct [ "@id", box productId ]

    match product with
    | [ [ priceObj; stockObj ] ] ->
        let price = System.Convert.ToDecimal(priceObj)
        let stock = System.Convert.ToInt32(stockObj)

        if stock >= orderQuantity then
            let totalPrice = price * decimal orderQuantity
            
            let actions = [
                ("UPDATE Products SET Quantity = Quantity - @quantity WHERE ProductID = @id;",
                 [ "@id", box productId; "@quantity", box orderQuantity ])
                 
                ("INSERT INTO Orders (ProductID, Quantity, TotalPrice) VALUES (@id, @quantity, @totalPrice);",
                 [ "@id", box productId; "@quantity", box orderQuantity; "@totalPrice", box totalPrice ])
            ]

            Ok(actions, totalPrice)
        else
            Error(sprintf "Insufficient stock. Available: %d, Required: %d" stock orderQuantity)
    | _ ->
        Error("Product not found.")



    //Generate Repors:-

let generateLowStockReport threshold =
    let query, parameters = checkLowStock threshold
    query, parameters

let calculateTotalSales () =
    let query = "SELECT SUM(TotalPrice) FROM Orders;"
    let result = executeReadQuery query []
    match result with
    | [ [ value ] ] -> Some(value)  
    | _ -> None  


let calculateInventoryValue () =
    let query = "SELECT SUM(Price * Quantity) FROM Products;"
    let result = executeReadQuery query [] 
    match result with
    | [ [ value ] ] -> Some(value)  
    | _ -> None




    //excute

[<EntryPoint>]
let main argv =

    //let query, parameters = addProduct "kuromi hand bag" 37.50m 18    //adding a product
    //executeQuery query parameters

    //let query, parameters = deleteProduct 3         //deleting a product
    //executeQuery query parameters

    //let query, parameters = updateProduct 12 "HP laptop" 407.99m 210     //updating products
    //executeQuery query parameters

    //let result = calculateInventoryValue ()         // calculating the whole inventory value
    //match result with
    //| Some(value) -> printfn "Inventory Value: %A" value
    //| None -> printfn "No data found or query failed."

    //let result = calculateTotalSales ()                       //caculate total sales from the orders table
    //match result with
    //| Some(value) -> printfn "Total Sales: %A" value
    //| None -> printfn "No data found or query failed."


    //let result = processOrder 10 6          //placing an order
    //match result with
    //| Ok(actions, totalPrice) ->
    //    actions |> List.iter (fun (query, parameters) -> executeQuery query parameters |> ignore)
    //    printfn "Order processed successfully. Total Price: %A" totalPrice
    //| Error message ->
    //    // Print the error message
    //    printfn "Error: %s" message

    //let query, parameters = generateLowStockReport 5        //generating a report for products that has low quantity 
    //let lowStockProducts = executeReadQuery query parameters
    //lowStockProducts |> List.iter (printfn "Low Stock: %A")


    0 // this is exit code