﻿module StocksManagement
open first


// Product Management

let addProduct name price quantity =
    "INSERT INTO Products (Name, Price, Quantity) VALUES (@name, @price, @quantity);",    //add product
    [ "@name", box name; "@price", box price; "@quantity", box quantity ]

let updateProduct productId name price quantity =
    let queryCheck = "SELECT Deleted FROM Products WHERE ProductID = @id;"               //update product
    let parametersCheck = [ "@id", box productId ] 
    let result = executeReadQuery queryCheck parametersCheck

    match result with
    | [[deletedObj]] -> 
        let deleted = System.Convert.ToBoolean(deletedObj)
        if deleted then
            None                    // when product cannot be updated
        else
            Some ("UPDATE Products SET Name = @name, Price = @price, Quantity = @quantity WHERE ProductID = @id;",
                   [ "@id", box productId; "@name", box name; "@price", box price; "@quantity", box quantity ])
    | _ -> None                     // Product not found

let deleteProduct productId =
    "UPDATE Products SET Deleted = TRUE WHERE ProductID = @id;",           //delete product
    [ "@id", box productId ]

// Inventory Tracking

let checkLowStock threshold =
    "SELECT * FROM Products WHERE Quantity < @threshold;",                //check for low stock products
    [ "@threshold", box threshold ]


let updateStockRecursively productsUpdates =                         //update inventory products quantity (add/subtract)
    let rec update products =
        match products with
        | [] -> []                                    // empty list, return an empty list
        | (productId, quantity) :: tail ->
            let queryCheck = "SELECT Deleted FROM Products WHERE ProductID = @id;"
            let parametersCheck = [ "@id", box productId ]
            
            let result = executeReadQuery queryCheck parametersCheck

            match result with
            | [[deletedObj]] -> 
                let deleted = System.Convert.ToBoolean(deletedObj)
                if deleted then
                    printfn "Product %d is deleted,will skip update." productId
                    update tail
                else
                    // Prepare the update query for the product
                    let queryUpdate = 
                        "UPDATE Products SET Quantity = Quantity + @quantity WHERE ProductID = @id AND Deleted = FALSE;"
                    let parametersUpdate = [ "@id", box productId; "@quantity", box quantity ]
                    // Recursively process the rest of the products
                    (queryUpdate, parametersUpdate) :: update tail
            | _ -> 
                // if product is not found, skip and continue with the rest of the list
                printfn "Product %d not found." productId
                update tail
    update productsUpdates


// Order Management

let processOrder productId orderQuantity =                                           //place an order
    let checkProductDeletedQuery = "SELECT Deleted FROM Products WHERE ProductID = @id;"
    let productStatus = executeReadQuery checkProductDeletedQuery [ "@id", box productId ]
    
    match productStatus with
    | [ [ deletedStatus ] ] ->
        let deleted = System.Convert.ToBoolean(deletedStatus)
        
        if deleted then
            Error("Cannot place an order for a deleted product.")
        else
            let queryProduct = "SELECT Price, Quantity FROM Products WHERE ProductID = @id;"
            let product = executeReadQuery queryProduct [ "@id", box productId ]
            
            match product with
            | [ [ priceObj; stockObj ] ] ->
                let price = System.Convert.ToDecimal(priceObj)
                let stock = System.Convert.ToInt32(stockObj)

                if stock >= orderQuantity then
                    let totalPrice = price * decimal orderQuantity

                    let actions = [
                        ("UPDATE Products SET Quantity = Quantity - @quantity WHERE ProductID = @id;",
                         [ "@id", box productId; "@quantity", box orderQuantity ])
                         
                        ("INSERT INTO Orders (ProductID, Quantity, TotalPrice) VALUES (@id, @quantity, @totalPrice);",
                         [ "@id", box productId; "@quantity", box orderQuantity; "@totalPrice", box totalPrice ])
                    ]

                    Ok(actions, totalPrice)
                else
                    Error(sprintf "Insufficient stock. Available: %d, Required: %d" stock orderQuantity)
            | _ ->
                Error("Product not found.")
    | _ ->
        Error("Error checking product status.")

// Report Generators

let generateLowStockReport threshold =                        //generate report for low stock products
    let query = "SELECT * FROM Products WHERE Quantity < @threshold AND Deleted = FALSE;"
    let parameters = [ "@threshold", box threshold ]
    executeReadQuery query parameters


let calculateTotalSales () =
    let query = "SELECT SUM(TotalPrice) FROM Orders;"              //caculate total sold products from the orders table
    match executeReadQuery query [] with
    | [ [ value ] ] -> Some value
    | _ -> None

let calculateInventoryValue () =
    let query = "SELECT SUM(Price * Quantity) FROM Products WHERE Deleted = FALSE;"         //inventory value from the products table
    match executeReadQuery query [] with
    | [ [ value ] ] -> Some value
    | _ -> None

let executeQueries queries =
    queries |> List.map (fun (query, parameters) -> executeQuery query parameters)

// Execute

[<EntryPoint>]
let main argv =
    
    
    //let product1 = addProduct "toshiba wall fan" 109.99m 44             //add products
    //let product2 = addProduct "flowery bed sheet" 11.99m 18                        
    //let queries = [product1; product2] 
    //queries |> List.iter (fun (query, parameters) -> executeQuery query parameters |> ignore)

    //let updateProductQuery = updateProduct 7 "dancing cactus" 103.00m 23                  //update prodct
    //match updateProductQuery with 
    //| Some (query, parameters) -> executeQuery query parameters |> ignore
    //| None -> printfn "Product cannot be updated."

    //let productId = 11  
    //let deleteQuery = deleteProduct productId                                          //delete product
    //let query, parameters = deleteQuery  
    //executeQuery query parameters |> ignore

    //let orderProductId = 6 
    //let orderQuantity = 4
    //let result = processOrder orderProductId orderQuantity                              //place an order
    //match result with
    //| Ok(actions, totalPrice) ->
    //    actions |> List.iter (fun (query, parameters) -> executeQuery query parameters |> ignore)
    //    printfn "Order processed successfully. Total Price: %A" totalPrice
    //| Error message ->
    //    printfn "Error: %s" message

    //let productsToUpdate = [(7, 3); (6, 3)]                                     //update products quantity
    //let queries = updateStockRecursively productsToUpdate
    //queries |> List.iter (fun (query, parameters) -> executeQuery query parameters |> ignore)


    //let lowStockProducts = generateLowStockReport 15                         //generate low stock product list report
    //lowStockProducts |> List.iter (printfn "Low Stock Product: %A")

    //match calculateTotalSales () with                                       //total sales 
    //| Some value -> printfn "Total Sales: %A" value 
    //| None -> printfn "Could not calculate total sales."

    //match calculateInventoryValue () with                                    //total inventory value
    //| Some value -> printfn "Inventory Value: %A" value
    //| None -> printfn "Could not calculate inventory value."
    System.Console.ReadLine() |> ignore
    0 // Exit 
