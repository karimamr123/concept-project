﻿module first
open System
open System.Data
open MySql.Data.MySqlClient

let connectionString = "Server=localhost;Database=StockManagement;User Id=root;Password=zeina123;"

let executeQuery (query: string) (parameters: (string * obj) list) =
    use connection = new MySqlConnection(connectionString)
    connection.Open()
    use command = new MySqlCommand(query, connection)
    for (key, value) in parameters do
        command.Parameters.AddWithValue(key, value) |> ignore
    command.ExecuteNonQuery()

let executeReadQuery (query: string) (parameters: (string * obj) list) =
    use connection = new MySqlConnection(connectionString)
    connection.Open()
    use command = new MySqlCommand(query, connection)
    for (key, value) in parameters do
        command.Parameters.AddWithValue(key, value) |> ignore
    use reader = command.ExecuteReader()
    [ while reader.Read() do
        [ for i in 0 .. reader.FieldCount - 1 -> reader.GetValue(i) ] ]





